# Change Log

## [1.0.0] 2018-10-14
### Stable Original Release

## [1.0.1] 2018-12-03
### Minor updates
- Upgrade packages
- Change sidebar gradient colors (more pleasant)
- Make links "bolder" in the sidebar so they are more readable
